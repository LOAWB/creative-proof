VELOCITY ENGINE, STATIC ADS, BATCH 06
Built by Approved Scale

WHAT IS IN HERE
Nine ads, each in the two sizes you run, 18 files at full resolution.
  1x1 is 1080 x 1080, the square feed placement.
  9x16 is 1080 x 1920, the vertical placement: stories, reels and TikTok.
Both sizes of an ad carry the same words. They are built from one source, so
the copy cannot drift between them. The vertical is not a crop of the square:
each layout is rebuilt for the taller frame, and the type and spacing are set
for a full screen phone rather than stretched.

THE ADS
  01-quiz        the bottleneck quiz
  02-versus      us against a general agency
  03-stop        the STOP interrupt
  04-hero        compliance hero
  05-notes       the Notes screenshot
  06-news        breaking news
  07-arc         what you get, as one diagram
  08-info        done for you, properly
  09-dark        anyone can launch

ALSO-4X5 (9 files)
The same nine ads at 1080 x 1350. This was the second size in the first
version of this batch, before the set was rebuilt to square and vertical.
It is kept because it is finished and approved work, and it is in its own
folder so it is never mistaken for one of the two sizes above.

NOT-FOR-USE-PENDING-REVIEWS (3 files)
This folder holds a tenth layout, the review cards. It is finished as a
layout but the quotes are deliberately blank, and the frame says so on its
face. It is kept separate so it cannot be run by mistake. Send real reviews
with permission to use them and it gets filled in and moved into the set.

TWO THINGS THAT ARE NOT ON THESE ADS, ON PURPOSE
No performance figures. No real Velocity numbers were supplied, and an
invented one would be a claim about your own results that you would be the
one to carry. Send the real numbers and a metrics version gets built the
same day.
No testimonials. Same reason. Nothing here is fabricated.

Approved Scale
