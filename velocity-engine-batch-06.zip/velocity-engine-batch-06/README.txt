VELOCITY ENGINE, STATIC ADS, BATCH 06
Built by Approved Scale, 2026-09-03

WHAT IS IN HERE
Nine ads, each in two sizes, 18 files at full resolution.
  1x1 is 1080 x 1080, the square feed placement.
  4x5 is 1080 x 1350, the taller feed placement.
Both sizes of an ad carry the same copy. They are built from one source, so the
wording cannot drift between them.

THE ADS
  01-quiz        the bottleneck quiz
  02-versus      us against a general agency
  03-stop        the STOP interrupt
  04-hero        compliance hero
  05-notes       the Notes screenshot
  06-news        breaking news
  07-arc         what you get, as one diagram
  08-info        done for you, properly
  09-dark        anyone can launch

NOT-FOR-USE-PENDING-REVIEWS
This folder holds a tenth layout, the review cards. It is finished as a layout
but the quotes are deliberately blank, and the frame says so on its face. It is
kept separate so it cannot be run by mistake. Send real reviews with permission
to use them and it gets filled in and moved into the main set.

TWO THINGS THAT ARE NOT ON THESE ADS, ON PURPOSE
No performance figures. No real Velocity numbers were supplied, and an invented
one would be a claim about your own results that you would be the one to carry.
Send the real numbers and a metrics version gets built the same day.
No testimonials. Same reason. Nothing here is fabricated.

Approved Scale
