FORTIQUE LABS - EMAIL HERO GRAPHICS
8 files, 1200 x 520 px PNG (2x the 600px email content width, for retina).

One hero per email in the Omnisend set:
  01-welcome                    Welcome 1
  02-welcome-order-moves        Welcome 2, how an order moves
  03-welcome-what-we-can-say    Welcome 3, what we can and cannot tell you
  04-abandoned-cart             Abandoned cart
  05-abandoned-checkout         Abandoned checkout
  06-browse-abandonment         Browse abandonment
  07-order-confirmation         Order confirmation
  08-winback                    Winback

Built from Fortique's own product photography as published on
fortiquelabs.com. No text is baked into any of these files, so the headline
and copy stay editable in Omnisend and still read when a mail client blocks
images. The only words visible are the ones printed on the vial label in the
photograph itself.

Three product shots in the shared Drive folder were NOT used: the vials
labelled Retatrutide, Tirzepatide and Semaglutide. The fortiquelabs.com shop
sells those three as GLP-1, GLP-2 and GLP-3 and never prints the compound
name, so the store's own GLP artwork was used instead.
