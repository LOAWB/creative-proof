Twyn Wellness, ad batch 01.

20 files: 10 ads at 1:1 and 9:16. Both are the sizes that run.
No 4:5 in this set.

Each file is named for the argument's composition. The ten:
  01  crossed            Held in the US. Shipped from the US.
  02  news               Ordered today. Moving today.
  03  question-based     Who answers when something is wrong?
  04  features-callout   Clear product information.
  05  us-vs-them         In stock beats impressive.
  06  features-list      Packed to arrive intact.
  07  negative-command   Do not buy on urgency.
  08  quiz               No promises. Just supply.
  09  app                One shelf. One checkout.
  10  question-angled    Ordered securely. Handled carefully.

Labels carry the twyn logotype only: no compound name, no dose,
no purity language, and no destination named in the call to action.
