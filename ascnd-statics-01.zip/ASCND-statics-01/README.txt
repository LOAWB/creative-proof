ASCND Research, static set 01.

16 files: 8 ads at 1x1 and 9x16.

One ad per angle from the Concept client creative guide. The eight:
  01  coa-first      Check the COA First
  02  checklist      The Buyer's Checklist
  03  crossed        Proof Over Hype
  04  lot-stamp      The Lot Number Test
  05  source-split   No Mystery Sourcing
  06  lab-spec       Lab Tested Isn't Specific Enough
  07  fulfilment     Fast, Documented, Domestic
  08  custody-path   Chain of Custody

Every claim traces to a line on the live ASCND site, read 2026-09-12.
Labels carry the ascnd wordmark only: no compound name, no dose, no percentage.
The required disclaimer is on every file.
