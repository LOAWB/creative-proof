MRP, My Research Peptides, static set 01.

15 files: 15 ads at 1:1.

Each file is named for the argument's composition. The fifteen:
  01  crossed            Read the certificate.
  02  news               Flat rate, every order.
  03  question-based     Who tested it?
  04  features-callout   Four facts on every vial.
  05  us-vs-them         Documents beat adjectives.
  06  features-list      Why researchers choose MRP.
  07  negative-command   Do not order without the paperwork.
  08  quiz               Batch specific. Public.
  09  app                The COA library.
  10  question-angled    Value you can verify.
  11  hero-word          TESTED.
  12  stat-card          Three numbers you can hold us to.
  13  lot-stamp          Every lot has a number. Every number has a certificate.
  14  checklist          Ask these before you order anywhere.
  15  editorial          Research without compromise.

Labels carry the MRP lockup and tagline only: no compound name, no dose,
no purity language. The call to action points at the public COA library.
